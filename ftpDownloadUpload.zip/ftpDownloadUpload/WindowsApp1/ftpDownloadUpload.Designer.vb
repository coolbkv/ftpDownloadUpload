﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class fmbFtp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.tabControl = New System.Windows.Forms.TabControl()
        Me.tabLogin = New System.Windows.Forms.TabPage()
        Me.lblLogin = New System.Windows.Forms.Label()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtUser = New System.Windows.Forms.TextBox()
        Me.txtHost = New System.Windows.Forms.TextBox()
        Me.tabDownload = New System.Windows.Forms.TabPage()
        Me.txtLog = New System.Windows.Forms.TextBox()
        Me.lblRequestID = New System.Windows.Forms.Label()
        Me.txtRequestID = New System.Windows.Forms.TextBox()
        Me.btnDownload = New System.Windows.Forms.Button()
        Me.tabUpload = New System.Windows.Forms.TabPage()
        Me.tabControl.SuspendLayout()
        Me.tabLogin.SuspendLayout()
        Me.tabDownload.SuspendLayout()
        Me.SuspendLayout()
        '
        'tabControl
        '
        Me.tabControl.Controls.Add(Me.tabLogin)
        Me.tabControl.Controls.Add(Me.tabDownload)
        Me.tabControl.Controls.Add(Me.tabUpload)
        Me.tabControl.Location = New System.Drawing.Point(10, 8)
        Me.tabControl.Name = "tabControl"
        Me.tabControl.SelectedIndex = 0
        Me.tabControl.Size = New System.Drawing.Size(312, 283)
        Me.tabControl.TabIndex = 3
        '
        'tabLogin
        '
        Me.tabLogin.Controls.Add(Me.lblLogin)
        Me.tabLogin.Controls.Add(Me.btnLogin)
        Me.tabLogin.Controls.Add(Me.Label3)
        Me.tabLogin.Controls.Add(Me.Label2)
        Me.tabLogin.Controls.Add(Me.Label1)
        Me.tabLogin.Controls.Add(Me.txtPassword)
        Me.tabLogin.Controls.Add(Me.txtUser)
        Me.tabLogin.Controls.Add(Me.txtHost)
        Me.tabLogin.Location = New System.Drawing.Point(4, 22)
        Me.tabLogin.Name = "tabLogin"
        Me.tabLogin.Padding = New System.Windows.Forms.Padding(3)
        Me.tabLogin.Size = New System.Drawing.Size(304, 257)
        Me.tabLogin.TabIndex = 2
        Me.tabLogin.Text = "Login"
        Me.tabLogin.UseVisualStyleBackColor = True
        '
        'lblLogin
        '
        Me.lblLogin.AutoSize = True
        Me.lblLogin.ForeColor = System.Drawing.Color.Red
        Me.lblLogin.Location = New System.Drawing.Point(17, 220)
        Me.lblLogin.Name = "lblLogin"
        Me.lblLogin.Size = New System.Drawing.Size(155, 13)
        Me.lblLogin.TabIndex = 7
        Me.lblLogin.Text = "Fill the details and Click Login..."
        '
        'btnLogin
        '
        Me.btnLogin.Location = New System.Drawing.Point(76, 137)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(75, 23)
        Me.btnLogin.TabIndex = 6
        Me.btnLogin.Text = "Login"
        Me.btnLogin.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(14, 100)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Password:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(38, 71)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "User:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(38, 42)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Host:"
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(76, 94)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(88)
        Me.txtPassword.Size = New System.Drawing.Size(206, 20)
        Me.txtPassword.TabIndex = 2
        '
        'txtUser
        '
        Me.txtUser.Location = New System.Drawing.Point(76, 68)
        Me.txtUser.Name = "txtUser"
        Me.txtUser.Size = New System.Drawing.Size(206, 20)
        Me.txtUser.TabIndex = 1
        '
        'txtHost
        '
        Me.txtHost.Location = New System.Drawing.Point(76, 42)
        Me.txtHost.Name = "txtHost"
        Me.txtHost.Size = New System.Drawing.Size(206, 20)
        Me.txtHost.TabIndex = 0
        '
        'tabDownload
        '
        Me.tabDownload.Controls.Add(Me.txtLog)
        Me.tabDownload.Controls.Add(Me.lblRequestID)
        Me.tabDownload.Controls.Add(Me.txtRequestID)
        Me.tabDownload.Controls.Add(Me.btnDownload)
        Me.tabDownload.Location = New System.Drawing.Point(4, 22)
        Me.tabDownload.Name = "tabDownload"
        Me.tabDownload.Padding = New System.Windows.Forms.Padding(3)
        Me.tabDownload.Size = New System.Drawing.Size(304, 257)
        Me.tabDownload.TabIndex = 0
        Me.tabDownload.Text = "Download"
        Me.tabDownload.UseVisualStyleBackColor = True
        '
        'txtLog
        '
        Me.txtLog.Location = New System.Drawing.Point(7, 76)
        Me.txtLog.Multiline = True
        Me.txtLog.Name = "txtLog"
        Me.txtLog.ReadOnly = True
        Me.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtLog.Size = New System.Drawing.Size(280, 168)
        Me.txtLog.TabIndex = 3
        Me.txtLog.Text = "Waiting for Download Command..."
        '
        'lblRequestID
        '
        Me.lblRequestID.AutoSize = True
        Me.lblRequestID.Location = New System.Drawing.Point(6, 41)
        Me.lblRequestID.Name = "lblRequestID"
        Me.lblRequestID.Size = New System.Drawing.Size(202, 13)
        Me.lblRequestID.TabIndex = 5
        Me.lblRequestID.Text = "Put the file name with path and download"
        '
        'txtRequestID
        '
        Me.txtRequestID.Location = New System.Drawing.Point(7, 15)
        Me.txtRequestID.MaxLength = 255
        Me.txtRequestID.Name = "txtRequestID"
        Me.txtRequestID.Size = New System.Drawing.Size(280, 20)
        Me.txtRequestID.TabIndex = 4
        '
        'btnDownload
        '
        Me.btnDownload.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnDownload.Location = New System.Drawing.Point(222, 41)
        Me.btnDownload.Name = "btnDownload"
        Me.btnDownload.Size = New System.Drawing.Size(65, 29)
        Me.btnDownload.TabIndex = 6
        Me.btnDownload.Tag = ""
        Me.btnDownload.Text = "Download"
        Me.btnDownload.UseVisualStyleBackColor = True
        '
        'tabUpload
        '
        Me.tabUpload.Location = New System.Drawing.Point(4, 22)
        Me.tabUpload.Name = "tabUpload"
        Me.tabUpload.Padding = New System.Windows.Forms.Padding(3)
        Me.tabUpload.Size = New System.Drawing.Size(304, 257)
        Me.tabUpload.TabIndex = 1
        Me.tabUpload.Text = "Upload"
        Me.tabUpload.UseVisualStyleBackColor = True
        '
        'fmbFtp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(328, 299)
        Me.Controls.Add(Me.tabControl)
        Me.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "fmbFtp"
        Me.Text = "ftp Download and Upload"
        Me.tabControl.ResumeLayout(False)
        Me.tabLogin.ResumeLayout(False)
        Me.tabLogin.PerformLayout()
        Me.tabDownload.ResumeLayout(False)
        Me.tabDownload.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents tabControl As TabControl
    Friend WithEvents tabDownload As TabPage
    Friend WithEvents txtLog As TextBox
    Friend WithEvents lblRequestID As Label
    Friend WithEvents txtRequestID As TextBox
    Friend WithEvents btnDownload As Button
    Friend WithEvents tabUpload As TabPage
    Friend WithEvents tabLogin As TabPage
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents txtUser As TextBox
    Friend WithEvents txtHost As TextBox
    Friend WithEvents btnLogin As Button
    Friend WithEvents lblLogin As Label
End Class
