﻿Imports WinSCP

Public Class fmbFtp
    Public sessionOptions As New SessionOptions
    Public connectionFlag As Boolean = False
    Private Sub btnDownload_Click(sender As Object, e As EventArgs) Handles btnDownload.Click
        txtLog.Text = "Waiting for Download Command..."
        If txtRequestID.Text = "" Then
            MsgBox("File and path can not be null", vbCritical, "Error:")
            Exit Sub
        End If

        Try
            txtLog.Text = txtLog.Text & vbNewLine & "---" & vbNewLine & "Connected..."
            Using session As New Session
                session.Open(sessionOptions)
                txtLog.Text = txtLog.Text & vbNewLine & "---" & vbNewLine & "Session Opened..."
                ' Upload files
                Dim transferOptions As New TransferOptions
                transferOptions.TransferMode = TransferMode.Binary

                Dim transferResult As TransferOperationResult
                txtLog.Text = txtLog.Text & vbNewLine & "---" & vbNewLine & "File Download in progress..."
                transferResult = session.GetFiles(txtRequestID.Text, My.Computer.FileSystem.CurrentDirectory & "\Download\")
                ' Throw on any error
                transferResult.Check()
                ' Print results
                For Each transfer In transferResult.Transfers
                    Console.WriteLine("Upload of {0} succeeded", transfer.FileName)
                Next
            End Using
            txtLog.Text = txtLog.Text & vbNewLine & "---" & vbNewLine & "Download Completed..."
        Catch ex As Exception
            txtLog.Text = txtLog.Text & vbNewLine & "---" & vbNewLine & "Error: " & ex.Message
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub txtRequestID_TextChanged(sender As Object, e As EventArgs)
        txtLog.Text = "Waiting for Download Command..."
    End Sub

    Private Sub fmbFtp_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtRequestID.Select()
        If (Not My.Computer.FileSystem.DirectoryExists(My.Computer.FileSystem.CurrentDirectory & "\Download")) Then
            MsgBox("Creating folder Files")
            My.Computer.FileSystem.CreateDirectory(My.Computer.FileSystem.CurrentDirectory & "\Download")
        End If

        If (Not My.Computer.FileSystem.DirectoryExists(My.Computer.FileSystem.CurrentDirectory & "\Upload")) Then
            MsgBox("Creating folder Files")
            My.Computer.FileSystem.CreateDirectory(My.Computer.FileSystem.CurrentDirectory & "\Upload")
        End If
    End Sub

    Private Sub txtRequestID_KeyPress(sender As Object, e As KeyPressEventArgs)
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Asc(e.KeyChar) <> 22 AndAlso Not IsNumeric(e.KeyChar) Then
            MsgBox("Please enter numbers only", vbCritical, "Number Only:")
            e.Handled = True
        End If
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Try
            ' Setup session options
            With sessionOptions
                .Protocol = Protocol.Sftp
                .HostName = txtHost.Text
                .UserName = txtUser.Text
                .Password = txtPassword.Text
                'telnet command to get key
                'ssh-keygen - l - f / etc / ssh / ssh_host_rsa_key
                .SshHostKeyFingerprint = "ssh-rsa 2048 d8:06:28:ad:66:af:07:da:b9:d1:b3:5d:0e:4e:43:ce"
            End With
            lblLogin.Text = "FTP connection in progress..."
            Using session As New Session
                ' Connect
                session.Open(sessionOptions)
                lblLogin.Text = "FTP connected successfully..."
                lblLogin.ForeColor = Color.Green
                connectionFlag = True
            End Using
        Catch ex As Exception
            lblLogin.Text = ex.Message
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub tabControl_Click(sender As Object, e As EventArgs) Handles tabControl.Click
        If tabControl.SelectedIndex <> 0 And connectionFlag = False Then
            MsgBox("No Active Session", vbCritical, "Error:")
            tabControl.SelectedIndex = 0
        End If

        If tabControl.SelectedIndex = 2 And connectionFlag = True Then
            MsgBox("In progress...", vbCritical, "Error:")
            tabControl.SelectedIndex = 0
        End If
    End Sub
End Class
